  <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>    
    <!-- /.container -->
<footer>
<div class="container">
          <div class="row">
                <div class="col-lg-12">
                <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.html">
        <img alt="Brand" src="images/footer.jpg">
      </a>
    </div>
    <ul class="nav navbar-nav">
                
      <li><a href="aboutus.php"> ABOUT POOL</a>  </li>
       <li><a href="FAQ.php">   FAQ  </a>  </li>
         <li><a href="#">   CONCIERGE </a> </li> 
          <li><a href="privacy.php">     PRIVACY POLICY  </a></li>   
             <li><a href="terms.php">   TERMS OF USE </a></li>   
             <li><a href="contactus.php">    CONTACT US</a></li>
    </ul>


                   
                </div>
                </nav>
            </div>
            </div>
            </div>
            <!-- /.row -->
            
        </footer>
        
        <div class="container-fluid socialsec">
            <div class="container">
            <div class="col-lg-12">
            <div class="col-lg-6">
            <p>© 2016 - Pool all rights reserved</p>
            </div>
            <div class="col-lg-6">
            <ul class="list-inline social">
    <li><a href="#"><img src="images/fb.png"></a></li>
    <li><a href="#"><img src="images/tw.png"></a></li>
    <li><a href="#"><img src="images/in.png"></a></li>
    <li><a href="#"><img src="images/g.png"></a></li>
  </ul>
            </div>
            </div>
            </div>
            </div>
